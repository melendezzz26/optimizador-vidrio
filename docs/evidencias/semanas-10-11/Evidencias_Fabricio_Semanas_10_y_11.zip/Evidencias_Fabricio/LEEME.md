# Evidencias — semanas 10 y 11

Abre SEMANA-10.html o SEMANA-11.html en tu navegador. Funcionan sin conexión y mantienen la estructura persona → actividad → tarea. Los archivos SEMANA-10.md y SEMANA-11.md incluyen texto e imágenes con rutas relativas para copiar o importar; conserva las carpetas al moverlos.

- Semana 10: exclusivamente optimizador-vidrio, integration-02 y demás ramas remotas.
- Semana 11: optimizador-vidrio, newglass-frontend y newglass-backend; todas las ramas remotas disponibles.
- Autoría: alias Fabricio Melendez / MQ y Wilder Fabricio, según confirmación del usuario. No se atribuyen cambios de fabrilar1, Andro ni Luis.
- Fechas de autor en Perú, límites inclusivos; fecha de captura 11/11/2026. No se confundieron con fecha de commit/integración.
- 92 PNG: capturas nuevas de terminal, código e interfaz, más un gráfico histórico SP-006 expresamente identificado.
- Inventario: semana-10/commits.csv y semana-11/commits.csv. Los commits de otras tareas se conservan allí, pero la selección visual sigue la estructura solicitada y sus continuaciones. No equivale a contar aportes únicos: hay merges, reversiones e historial filtrado entre repositorios.
- La columna integrated indica pertenencia a integration-02 en el monorepo y a origin/main en los repositorios separados en el momento de consulta. Es presencia en el grafo, no aprobación de PR. Los commits citados en los informes tienen autoría filtrada; no se atribuye todo el código final de un archivo a una sola persona.

## Resultados de esta revisión

Ver VALIDACION.csv y los logs originales. SP-006: 47; selección M6/adaptadores: 154; frontend: 217 unitarias + 648 componentes; supervisor: 32; perfil: 7; E2E: B07 histórico y dos escenarios actuales aprobados. No se ejecutó una sesión de Colab, una carga nueva de 800 piezas, una extracción nueva de repositorios ni un despliegue externo.

## Diagnóstico y límites

SP-006 falló inicialmente al usar el cierre del 07/11: falta de contexto Git de la copia exportada y diferencias de WF por cambios posteriores. La reproducción correcta usó la revisión original 3cc90bcbd y el contexto Git de lectura del monorepo. Se conservan ambos logs; no se modificaron pruebas ni algoritmos para obtener el resultado final.

El primer intento E2E de semana 11 falló por la ruta ../backend esperada por los helpers. Se creó un alias local hacia el checkout existente; la repetición pasó. No se cambiaron pruebas ni código de aplicación.

La máquina carece de /proc/<pid>/task/<pid>/children. La prueba específica de descubrimiento de descendientes falló durante la preparación anterior, por lo que los resultados de supervisión presentados no certifican esa capacidad ausente. El notebook mantiene pendiente la conclusión humana de SP-006; no se presenta como aprobación formal.

Los rótulos T01/T02/T03 de semana 11 son una agrupación propuesta a partir de commits. No se escribieron datos en Notion ni GitHub, no se hicieron commits y no se modificaron archivos de los tres repositorios.

MANIFIESTO-CAPTURAS.json registra rutas y SHA-256. capturas-plan.json registra la fuente de los fragmentos de código. Fuentes exportadas, node_modules y entornos virtuales se excluyen del ZIP para mantenerlo ligero y sin dependencias locales.

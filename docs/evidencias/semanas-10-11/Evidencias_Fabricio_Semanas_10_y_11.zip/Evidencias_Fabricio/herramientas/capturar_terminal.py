import os,subprocess,time,pathlib,json
B=pathlib.Path('/workspace/evidencias-semanas'); env={**os.environ,'DISPLAY':':97'}
specs=json.loads((B/'capturas-plan.json').read_text());script=B/'herramientas/screens.sh';commands=[]
for i,s in enumerate(specs):
 for flag in ['ready','next']:(B/'herramientas'/f'{flag}-{i}').unlink(missing_ok=True)
 content='\033[1;36m'+s['title']+'\033[0m\n'+s['meta']+'\n'+'─'*105+'\n'+s['body']+'\n'
 txt=B/'herramientas'/f'screen-{i}.txt';txt.write_text(content)
 commands.append("printf '\\033[2J\\033[H'\ncat "+str(txt)+'\ntouch '+str(B/'herramientas'/f'ready-{i}')+'\nwhile [ ! -f '+str(B/'herramientas'/f'next-{i}')+' ]; do sleep .05; done\n')
script.write_text('#!/bin/bash\n'+ '\n'.join(commands))
p=subprocess.Popen(['xfce4-terminal','--disable-server','--geometry=145x42+0+0','--hide-menubar','--hide-toolbar','--hide-scrollbar','--font=DejaVu Sans Mono 14','--color-bg=#101720','--color-text=#e4ebf3','--command=bash '+str(script)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 for i,s in enumerate(specs):
  ready=B/'herramientas'/f'ready-{i}'
  for _ in range(150):
   if ready.exists():break
   time.sleep(.1)
  assert ready.exists(),s['id']
  time.sleep(.35)
  dest=B/f"semana-{s['week']}"/s['kind']/(s['id']+'.png');dest.parent.mkdir(exist_ok=True)
  subprocess.run(['import','-window','root',str(dest)],env=env,check=True)
  print(dest,flush=True)
  (B/'herramientas'/f'next-{i}').touch()
finally:
 p.terminate()
 try:p.wait(timeout=4)
 except subprocess.TimeoutExpired:p.kill()

import subprocess,json,datetime,zoneinfo,pathlib,csv
B=pathlib.Path('/workspace/evidencias-semanas'); TZ=zoneinfo.ZoneInfo('America/Lima')
def git(repo,*args): return subprocess.check_output(['git','-C','/workspace/'+repo,*args],text=True).rstrip("\n")
def own(author,email):return author.lower() in ['fabricio','fabricio dev','fabricio melendez quezada','wilder fabricio','wilder fabricio melendez quezada'] or email.lower().split('@')[0] in ['fabrimq2602','fmq2602','wmelendezq1']
allrows=[]
for repo in ['optimizador-vidrio','newglass-frontend','newglass-backend']:
 rows=[]
 for line in git(repo,'log','--all','--format=%H%x1f%aI%x1f%cI%x1f%an%x1f%ae%x1f%s%x1f%P').splitlines():
  sha,ad,cd,author,email,subject,parents=line.split('\x1f');day=datetime.datetime.fromisoformat(ad).astimezone(TZ).date().isoformat()
  if not '2026-10-28'<=day<='2026-11-11':continue
  week=10 if day<='2026-11-07' else 11
  if week==10 and repo!='optimizador-vidrio':continue
  ownflag=own(author,email);merge=len(parents.split())>1
  target='origin/integration-02' if repo=='optimizador-vidrio' else 'origin/main'
  integrated=subprocess.run(['git','-C','/workspace/'+repo,'merge-base','--is-ancestor',sha,target],capture_output=True).returncode==0
  refs=git(repo,'for-each-ref','--contains='+sha,'--format=%(refname:short)','refs/remotes/origin').splitlines()
  row=dict(repo=repo,week=week,sha=sha,date=day,author_date=ad,commit_date=cd,author=author,own=ownflag,merge=merge,subject=subject,integrated=integrated,integration_ref=target,branches=refs,url=f'https://github.com/melendezzz26/{repo}/commit/{sha}')
  rows.append(row);allrows.append(row)
 (B/(repo+'-auditoria.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2))
for w in [10,11]:
 rows=[r for r in allrows if r['week']==w and r['own']]
 (B/f'semana-{w}'/'commits.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 fields=['repo','sha','date','author','subject','merge','integrated','integration_ref','branches','url']
 with (B/f'semana-{w}'/'commits.csv').open('w') as f:
  wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
  for r in rows:wr.writerow({k: '; '.join(r[k]) if isinstance(r[k],list) else r[k] for k in fields})
 print('SEMANA',w,len(rows),'commits autor; sin merge',sum(not r['merge'] for r in rows))
(B/'auditoria-completa.json').write_text(json.dumps(allrows,ensure_ascii=False,indent=2))

import pathlib,json,subprocess,sys
sys.path.insert(0,'/workspace/.venvs/newglass/lib/python3.11/site-packages')
from pygments import highlight
from pygments.lexers import PythonLexer,JavascriptLexer,TextLexer
from pygments.formatters import Terminal256Formatter
B=pathlib.Path('/workspace/evidencias-semanas');S=[];sha=(B/'semana10-sha.txt').read_text().strip()
def git(repo,*args):return subprocess.check_output(['git','-C','/workspace/'+repo,*args],text=True).rstrip('\n')
def code(w,id,title,repo,rev,path,start,n=25):
 source=git(repo,'show',rev+':'+path).splitlines()
 selected=[]; rows=0
 for line in source[start-1:start+n-1]:
  extra=max(1,(len(line.expandtabs(4))+6+138)//139)
  if rows+extra>29:break
  selected.append(line);rows+=extra
 n=len(selected);fragment='\n'.join(selected)
 lex=PythonLexer() if path.endswith('.py') else JavascriptLexer() if path.endswith(('.js','.jsx')) else TextLexer()
 color=highlight(fragment,lex,Terminal256Formatter(style='monokai')).splitlines()
 body='\n'.join(f'\033[38;5;245m{start+i:>4}  \033[0m'+v for i,v in enumerate(color))
 S.append(dict(week=w,id=id,kind='codigo',title=title,meta=f'{repo} @ {git(repo,"rev-parse",rev)[:12]} | Fragmento de codigo versionado\n{path} | lineas {start}-{min(start+n-1,len(source))}',body=body,source_path=path,source_commit=git(repo,'rev-parse',rev)))
def terminal(w,id,title,repo,commits,log=None,command=None):
 body='Consulta Git (fecha de autor; zona original visible):\n\n'
 for c in commits:body+=git(repo,'show','-s','--format=%h | %aI | %an%n%s',c)+'\n\n'
 if log:
  raw=(B/log).read_text();lines=raw.splitlines(); chosen=[l for l in lines if ('passed' in l and '[WebServer]' not in l) or ' failed' in l or l.startswith('ℹ tests') or l.startswith('ℹ pass') or l.startswith('ℹ fail')]
  body+='\033[1;32mResultado real de reproduccion local (11/11/2026)\033[0m\nComando registrado: '+(command or 'ver comando en el informe')+'\n'+'\n'.join(chosen[-6:])+'\nLog: '+log
 S.append(dict(week=w,id=id,kind='terminal',title=title,meta='Captura nueva de terminal real | Las fechas de commits no son fechas de captura',body=body,commits=commits,log=log))
code(10,'SP006-T01-estudio','SP-006 / T01 - Investigar heuristica M6','optimizador-vidrio','3cc90bcbd','experiments/sp-006-m6/sp006/beam.py',90)
code(10,'TA053-T01-m6','TA-053 / T01 - Implementar heuristica M6','optimizador-vidrio',sha,'backend/app/modules/optimization/domain/beam_search.py',153)
code(10,'TA053-T02-pruebas','TA-053 / T02 - Pruebas de heuristica M6','optimizador-vidrio',sha,'backend/tests/unit/optimization/test_beam_search_t02.py',1)
code(10,'TA043-T01-catalogo','TA-043 / T01 - Registro extensible de seis metodos','optimizador-vidrio',sha,'backend/app/modules/optimization/application/comparison_catalog.py',33)
code(10,'TA043-T02-adaptador','TA-043 / T02 - Seis metodos sobre copias equivalentes','optimizador-vidrio',sha,'backend/app/modules/optimization/application/engine_execution.py',69)
code(10,'TA043-T03-regresion','TA-043 / T03 - Regresion cruzada de seis metodos','optimizador-vidrio',sha,'backend/tests/unit/optimization/test_engine_execution.py',52)
code(10,'HU009-T01-pestanas','HU-009 / T01 - Pestanas de resultados multimetodo','optimizador-vidrio',sha,'frontend/src/features/optimization/ComparisonWorkspace.jsx',290,21)
code(10,'HU009-T02-comparacion','HU-009 / T02 - Comparacion visible de seis metodos','optimizador-vidrio',sha,'frontend/src/features/optimization/ComparisonWorkspace.jsx',305,22)
code(11,'ENREPO001-T01-extraccion','EN-REPO-001 - Extraccion de repositorios','optimizador-vidrio','d85f0827a','scripts/repository-split/prepare.py',1)
code(11,'ENUX001-T01-tabla','EN-UX-001 - Comparacion operativa compacta','newglass-frontend','HEAD','src/features/optimization/CompactComparisonTable.jsx',18,23)
code(11,'ENUX001-T02-medidas','EN-UX-001 - Consulta unica de medidas originales','newglass-frontend','HEAD','src/features/optimization/OriginalMeasuresTable.jsx',1)
code(11,'ENUX002-T01-inspector','EN-UX-002 - Inspector contextual de piezas','newglass-frontend','HEAD','src/features/optimization/PieceInspector.jsx',8,22)
code(11,'ENUX003-T01-historico','EN-UX-003 - Recuperacion del resultado historico','newglass-frontend','9ae9670','src/features/optimization/ComparisonWorkspace.jsx',124,23)
code(11,'ENUX004-T01-backend','EN-UX-004 - Cancelacion idempotente con cierre seguro','newglass-backend','HEAD','app/modules/optimization/presentation/comparison_supervision_v2.py',187)
code(11,'ENUX004-T02-interfaz','EN-UX-004 - Interfaz de cancelacion confirmada','newglass-frontend','HEAD','src/features/optimization/comparisonV2Contract.js',129,19)
terminal(10,'SP006-T01-git-pruebas','SEMANA 10 | SP-006 / T01 - Investigacion M6','optimizador-vidrio',['9524d2ef4','3cc90bcbd'],'semana-10/logs/sp006-pruebas-base-correcta.txt','/workspace/.venvs/sp006/bin/python -m pytest tests -q -ra')
terminal(10,'TA053-T01-T02-git-pruebas','SEMANA 10 | TA-053 / T01-T02 - Implementacion y pruebas M6','optimizador-vidrio',['c96a9719d','88ba5b99e'],'semana-10/logs/m6-adaptadores-pruebas.txt','python -m pytest tests/unit/optimization/test_beam_search.py tests/unit/optimization/test_beam_search_t02.py tests/unit/optimization/test_beam_search_fallback.py tests/unit/optimization/test_beam_memory_incremental.py tests/unit/optimization/test_engine_execution.py -q -ra')
terminal(10,'TA043-T01-T03-git-pruebas','SEMANA 10 | TA-043 / T01-T03 - Orquestacion multimetodo','optimizador-vidrio',['5dcc3164c','11f3d3fd5','70084ceac'],'semana-10/logs/m6-adaptadores-pruebas.txt','python -m pytest tests/unit/optimization/test_beam_search.py tests/unit/optimization/test_beam_search_t02.py tests/unit/optimization/test_beam_search_fallback.py tests/unit/optimization/test_beam_memory_incremental.py tests/unit/optimization/test_engine_execution.py -q -ra')
terminal(10,'HU009-T01-T02-git-interfaz','SEMANA 10 | HU-009 / T01-T02 - Patron y comparacion','optimizador-vidrio',['582762da3','bfce80826'],'semana-10/logs/interfaz-b07.txt','npx playwright test --config=/workspace/evidencias-semanas/playwright-s10.mjs --project=chromium-desktop --grep "TA-043 B07 smoke"')
terminal(11,'ENREPO001-git','SEMANA 11 | EN-REPO-001 - Separacion reproducible','optimizador-vidrio',['d85f0827a','b5214dd2b','9325e0df6'])
terminal(11,'TA043-TA053-continuidad-git','SEMANA 11 | TA-043 / TA-053 - Capacidad y rendimiento','optimizador-vidrio',['2cb11202d','13a83164d','0c5318ad3'])
terminal(11,'ENUX001-git','SEMANA 11 | EN-UX-001 - Resultados operativos','newglass-frontend',['e125b26','2f0b609','552520e'],'semana-11/logs/interfaz-b07-cancelacion-reintento.txt','npx playwright test --config=/workspace/evidencias-semanas/playwright-s11.mjs --project=chromium-desktop --grep "TA-043 B07 smoke|EN-UX-004: confirmación operario"')
terminal(11,'ENUX002-git','SEMANA 11 | EN-UX-002 - Seleccion e inspector','newglass-frontend',['63c480c','751b169','14c14eb'],'semana-11/logs/interfaz-b07-cancelacion-reintento.txt','npx playwright test --config=/workspace/evidencias-semanas/playwright-s11.mjs --project=chromium-desktop --grep "TA-043 B07 smoke|EN-UX-004: confirmación operario"')
terminal(11,'ENUX003-git','SEMANA 11 | EN-UX-003 - Recuperacion y claridad visual','newglass-frontend',['d2b145d','f6fc781','9ae9670'],'semana-11/logs/interfaz-b07-cancelacion-reintento.txt','npx playwright test --config=/workspace/evidencias-semanas/playwright-s11.mjs --project=chromium-desktop --grep "TA-043 B07 smoke|EN-UX-004: confirmación operario"')
terminal(11,'ENUX004-git-pruebas','SEMANA 11 | EN-UX-004 - Cancelacion segura','newglass-backend',['b24d612','3e0c639','8c32853'],'semana-11/logs/cancelacion-supervisor.txt','python -m pytest tests/integration/optimization/test_comparison_supervision_v2.py -q -ra')
terminal(11,'frontend-validacion','SEMANA 11 | Frontend - Regresiones de interfaz','newglass-frontend',['2fe1f4e'],'semana-11/logs/frontend-componentes.txt','npm run test:component')
terminal(11,'perfil-recursos-pruebas','SEMANA 11 | TA-043 / TA-053 - Perfil de recursos','optimizador-vidrio',['13a83164d'],'semana-11/logs/perfil-recursos.txt','python -m pytest tests/unit/optimization/test_resource_profile.py -q -ra')
(B/'capturas-plan.json').write_text(json.dumps(S,ensure_ascii=False,indent=2));print(len(S),'capturas planificadas')

const {chromium}=require('/workspace/newglass-frontend/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 for(const week of [10,11]){
  await page.goto(`http://127.0.0.1:8765/SEMANA-${week}.html`);
  await page.getByRole('button',{name:'Abrir todo'}).click();
  const result=await page.evaluate(async()=>{
   const images=[...document.images]; images.forEach(i=>i.loading='eager');
   await Promise.all(images.map(i=>i.decode().catch(()=>{})));
   return {tasks:document.querySelectorAll('details.task').length,images:images.length,broken:images.filter(i=>!i.naturalWidth).map(i=>i.getAttribute('src'))};
  });
  if(result.broken.length)throw new Error(JSON.stringify(result));
  console.log('Semana '+week,JSON.stringify(result));
 }
 await page.goto('http://127.0.0.1:8765/SEMANA-10.html');
 await page.locator('details.task').first().locator('summary').click();
 await page.screenshot({path:'/workspace/evidencias-semanas/vista-informe.png'});
 await browser.close();
})();

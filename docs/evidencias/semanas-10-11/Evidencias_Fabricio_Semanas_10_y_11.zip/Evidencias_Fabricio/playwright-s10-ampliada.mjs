import base from '/workspace/evidencias-semanas/fuentes/semana10/frontend/playwright.config.js';
export default {...base,projects:[{name:'chromium-desktop',use:{viewport:{width:1440,height:2000}}}],
testDir:'/workspace/evidencias-semanas/fuentes/semana10/frontend/tests/e2e',
globalTeardown:'/workspace/evidencias-semanas/fuentes/semana10/frontend/tests/e2e/globalTeardown.js',
reporter:[['list']],outputDir:'/workspace/evidencias-semanas/semana-10/test-results',
use:{...base.use,channel:undefined,launchOptions:{executablePath:'/usr/bin/chromium'}},
webServer:base.webServer.map((s,i)=>({...s,cwd:i===0?'/workspace/evidencias-semanas/fuentes/semana10/backend':'/workspace/evidencias-semanas/fuentes/semana10/frontend'}))};
